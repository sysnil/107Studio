$(function(){
	/*Header searchInput*/
	$(".searchInput").click(function(){
		$(this).css("background-color","#fff");
	});
	$(document).bind("click",function(e){
	
		if($(e.target).closest(".searchInput").length == 0){
			$(".searchInput").css("background-color","#F5AA02");
		}
	});

	/*nav*/
	$('.navContent li').mouseover(function(){
	    $(this).children().stop().slideToggle()
	});
	$(".navContent li").mouseout(function(){
	    $(this).children().stop().slideToggle()
    });

    /*Banner*/
    var oul = $(".Bmain ul");
	var numLi = $(".Bmain .dotsButton ol li");
	var aLi = $(".Bmain ul li");
	var aLiWidth = $(".Bmain ul li").eq(0).width(); 
	var now = 0;
	var now2 = 0;
	var timeIdB = null;
	var index;             
	numLi.click(function(){
		index = $(this).index();
		now2 = index;
		now = index;
		$(this).addClass("current").siblings().removeClass("current");
		oul.animate({'left':-aLiWidth*index},500);
	})
	var banner = function banner(){
		if(now == 3){
			aLi.eq(0).css({
				"position":"relative",
				"left":oul.width()
			});
			now = 0;
		}
		else{
			now++;
		}

		now2++;

		numLi.eq(now).addClass("current").siblings().removeClass("current");
		oul.animate({'left':-aLiWidth*now2},500,function(){
			if(now == 0){
				aLi.eq(0).css("position","static");
				oul.css("left",0);
				now2 = 0;
			}
		});	
	};
	// 定时器
	timeIdB = setInterval(banner,3000);
	//鼠标移入移出事件
	$(".Bmain").mouseover(function(){
		clearInterval(timeIdB);
	});
	$(".Bmain").mouseout(function(){
		timeIdB = setInterval(banner,3000);
	})
	//上一张下一张按钮
	$(".next").click(function(){
		banner();
	});
	$(".prev").click(function(){
		if(now == 0){
			aLi.eq(3).css({
				"position":"relative",
				"left":-oul.width()
			});
			now = 3;
		}
		else{
			now--;
		}
		now2--;
		numLi.eq(now).addClass("current").siblings().removeClass("current");
		oul.animate({"left":-aLiWidth*now2},500,function(){
			if(now == 3){
				aLi.eq(3).css("position","static");
				oul.css("left",-3*aLiWidth);
				now2 = 3;
			}
		});
	});
	/*Banner End*/

	/*poem Left*/
	var poem1Button = $(".poem1Button");
	var poem2Button = $(".poem2Button");
	poem1Button.click(function(){
		$(this).addClass("poemCurrent");
		poem2Button.removeClass("poemCurrent");
		$(".poem2").fadeToggle(300);
		$(".poem1").fadeToggle(1500);
	});	
	poem2Button.click(function(){
		$(this).addClass("poemCurrent");
		poem1Button.removeClass("poemCurrent");
		$(".poem1").fadeToggle(300);
		$(".poem2").fadeToggle(1500);
	});	

	/*Meeting*/
	var imgLittle = $(".meet-img ol li");
	var imgUl = $(".img-big ul");
	var LeftWidth = $(".LeftWidth").width();
	var number = 0,leftWidth = 0;
	var meetSelect = function(){
		leftWidth = -352*number;
		imgLittle.eq(number).addClass("imgCurrent").siblings().removeClass("imgCurrent");
		imgUl.animate({"left":leftWidth},500);
		imgLittle.eq(number).children("img").addClass("imgBorder");
		imgLittle.eq(number).siblings().children("img").removeClass("imgBorder");
	}

	imgLittle.click(function(){
		number = $(this).index();
		meetSelect();
	});

	var meetTimer = setInterval(function(){
		if(number == 3){
			number = 0;
		}
		else{
			number ++;
		}
		meetSelect();

	},3000);

	$(".meet-img").mouseover(function(){
		clearInterval(meetTimer);
	});
	$(".meet-img").mouseout(function(){
		meetTimer = setInterval(function(){
			if(number == 3){
				number = 0;
			}
			else{
				number ++;
			}
			meetSelect();
			},3000);
	});


	/*Poem Right*/
    var aMenuOneLi = $(".menu-one > li");
    var aMenuTwo = $(".menu-two");
    $(".menu-two").eq(0).show();
	$(".pheader").click(function(){ 
        $(this).addClass("menu-show").parent().siblings().children(".pheader").removeClass("menu-show");
        $(".menu-two").not($(this).next()).slideUp(500);
        $(this).next().slideDown(500);  
    });      


    /*slider*/

    var aul = $('.slider ul');
	var aulHtml = aul.html();
	aul.html(aulHtml + aulHtml);
	var timeId = null;

	function sliderTimer(){

		if(aul.css('left') == '-990px'){
			aul.css('left' , 0) ;
		}
		aul.css('left','+=-165px');

	};

	timeId = setInterval(sliderTimer,3000);

	$('.slider').mouseover(function(){
		clearInterval(timeId);
	});

	$('.slider').mouseout(function(){
		timeId = setInterval(sliderTimer,3000);
	});


	$('.goLeft').click(function(){
		aul.css('left','+=-165px');
		if(aul.css('left') == '-990px'){
			aul.css('left' , 0) ;
		}
	});

	$('.goRight').click(function(){
		if(aul.css('left') == '0px'){
			aul.css('left' , '-990px') ;
		}
		aul.css('left','+=165px');
	});




	/*dialog*/
	var docHeight = $(document).height();
	$(".img-select").find("img").on("click",function(){
		var $this = $(this);
		var $img = $this.attr("src");
		$(".dialog-box").find("img").attr("src",$img);
		$(".dialog-bg").css("height",docHeight);
		$(".dialog-bg").show();
	});

	$(".dialog-close").click(function(){
		$(".dialog-bg").hide();
	})

});