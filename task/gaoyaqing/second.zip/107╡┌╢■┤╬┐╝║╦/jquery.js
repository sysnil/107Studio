
//*********轮播图*********
$(function (){
	var oul = $('.images ul');
	var numLi = $('.images ol li');
	var aliwidth = $('.images ul li').eq(0).width();
	var _now = 0;  //计时器
	var timeId = null;  //计时器  不是一定为null,也可不写

	numLi.click(function(){
		var index = $(this).index();
		_now = index;  //同步
		$(this).addClass('current').siblings().removeClass();
		oul.animate({'left':-aliwidth*index},1540);
	});


	function slider (){    //图片运动的函数
		if(_now==3){
			_now=0;
		}else{
			_now++;
		}
		
		numLi.eq(_now).addClass('current').siblings().removeClass();
		oul.animate({'left':-aliwidth*_now},1540);  //每次滚动的距离是每一图片长度
	}

	timeId * setInterval(slider,3000);  //计时器,改变数值改变滑动时间

	$('.images').mouseover(function(){
		clearInterval(timeId);
	});

	$('.images').mouseout(function(){

		timeId = setInterval(slider,3000);
	});
});
//*****图片轮播-结束*****

//******中-会议*********
$(function (){
	var oul = $('.meet ul');
	var numLi = $('.meet ol li');
	var aliwidth = $('.meet ul li').eq(0).width();
	var _now = 0;  //计时器
	var timeId = null;  //计时器  不是一定为null,也可不写

	numLi.click(function(){
		var index = $(this).index();
		_now = index;  //同步
		$(this).addClass('current').siblings().removeClass();
		oul.animate({'left':-aliwidth*index},99);
	});


	function slider (){    //图片运动的函数
		if(_now==3){
			_now=0;
		}else{
			_now++;
		}
		
		numLi.eq(_now).addClass('current').siblings().removeClass();
		oul.animate({'left':-aliwidth*_now},99);  //每次滚动的距离是每一图片长度
	}

	timeId * setInterval(slider,3000);  //计时器,改变数值改变滑动时间

	$('.meet').mouseover(function(){
		clearInterval(timeId);
	});

	$('.meet').mouseout(function(){

		timeId = setInterval(slider,3000);
	});
});
//******中-会议结束*****

//******右-诗句*********
$(function(){
	var oBtn = $(".night");
	oBtn.click(function(){
		$(this).next('ul').slideToggle().siblings('ul').slideUp(); 
	});
});
 $(function(){
	var oBtn = $(".spring");
	oBtn.click(function(){
		$(this).next('ul').slideToggle().siblings('ul').slideUp(); 
	});
});
 $(function(){
	var oBtn = $(".rain");
	oBtn.click(function(){
		$(this).next('ul').slideToggle().siblings('ul').slideUp(); 
	});
}); 

//*****右-诗句结束******

//******风景*********

//*****风景结束******

//*****狗图片*********
$(function(){
	var oBtn = $('#o1');
	var popwindow = $('.popwindow1');
	var oClose = $('.popwindow1 h3 span img');
	
	oBtn.click(function(){
		popwindow.show();
	});
	oClose.click(function(){
		popwindow.hide();
	});
});

 $(function(){
	var oBtn = $('#o2');
	var popwindow = $('.popwindow2');
	var oClose = $('.popwindow2 h3 span img');
	
	oBtn.click(function(){
		popwindow.show();
	});
	oClose.click(function(){
		popwindow.hide();
	});
});

$(function(){
	var oBtn = $('#o3');
	var popwindow = $('.popwindow3');
	var oClose = $('.popwindow3 h3 span img');
	
	oBtn.click(function(){
		popwindow.show();
	});
	oClose.click(function(){
		popwindow.hide();
	});
});

$(function(){
	var oBtn = $('#o4');
	var popwindow = $('.popwindow4');
	var oClose = $('.popwindow4 h3 span img');
	
	oBtn.click(function(){
		popwindow.show();
	});
	oClose.click(function(){
		popwindow.hide();
	});
}); 
//*******狗图片结束*******
