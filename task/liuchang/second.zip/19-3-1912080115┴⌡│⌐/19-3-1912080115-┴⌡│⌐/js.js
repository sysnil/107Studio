$(function(){
        var len = $(".slider li").length-1;
        $(".slides").css({
            "width":((len+1)*100).toString()+"%",
        });//css设置ul宽度
        $(".slides li").css({
            "width":(100/(len+1)).toString()+"%",
        });//css设置li宽度  
        //全局变量
        var i=0;
        var aliWidth=$('.slider .slides li').eq(0).width();
        var timeId;
        //图片自动轮播
        $('.bottom ul li').click(function(){
    	    var index=$(this).index();
    	    i=index;
    	    $(this).addClass('box').siblings().removeClass();
            $('.slider .slides').animate({'left':-aliWidth*index},500);
        });
        function slider(){
    	    if(i==$('.bottom ul li').size()-1){
    		 i=0;
    	    }else{
    		 i++;
    	    }
    	    $('.bottom ul li').eq(i).addClass('box').siblings().removeClass();
    	    $('.slider .slides').animate({'left':-aliWidth*i},500);
            }
        timeId=setInterval(slider,1500);
        //鼠标进入停止滚动
        $('.slider').mouseover(function(){
    	    clearInterval(timeId);//消除计时器
        });
        $('.slider').mouseout(function(){
    	    timeId=setInterval(slider,1500);
        });
        //箭头控制图片移动
        $(".nextpic").click(function(){ //下一张
			next();
		});
		$(".lastpic").click(function(){ //上一张
			prev();
		})
		function next(){
			i++;
			if(i > 3){
					 $(".slides").animate({left:-(i-1)*aliWidth},500); 
					 i = 0;
					 $(".slides").animate({left:0},0); //
			        }
				     $(".slides").animate({left:-i*aliWidth},500);
				     iconHover(i);
		}//当图片到最后一张时跳回第一张。
		function prev(){
			i--;
			if(i < 0 ){
					i = 3;
					$(".slides").animate({left:-(i)*aliWidth},0);
				    }
				    $(".slides").animate({left:-i*aliWidth},500);
				    iconHover(i);
		}
		function iconHover(i){
			$(".bottom ul li").eq(i).addClass("box").siblings().removeClass("box");
			}
	//tab标签的内容及标签转换
        $('#tabs a').click(function(e) {
          e.preventDefault();                
          $('#tabs li').removeClass("current").removeClass("hoverItem");
          $(this).parent().addClass("current");
          $("#tab-content div").removeClass("show");//转换文字内容
          $('#' + $(this).attr('title')).addClass('show');
        });
        $('#tabs a').hover(function(){
          if(!$(this).parent().hasClass("current")){
          $(this).parent().addClass("hoverItem");
          }
          },function(){
            $(this).parent().removeClass("hoverItem");
        });
        //鼠标滑过文字变色
        $('#tab-content p,#footer .content ul li').mouseover(function(){
     	    $(this).css("color","red");
            }).mouseout(function(){
     	    $(this).css("color","");
            });	
        //中间图片切换
        $(".under li").mouseover(function(){
			var index = $(this).index();
			$(".img li").eq(index).show();
			$(".img li").eq(index).siblings().hide();
		    });//下方图片与上方图片索引对应
       //边框样式变换以及出现与消失
        $('.img1').mouseover(function(){
    	    $(this).css("border-color","#ec6b0e");
            }).mouseout(function(){
            $(this).css("border-color","#f2f2f2");
        });
        $('.img1-1').mouseover(function(){
            $('.icoTop1').css("display","block");
            }).mouseout(function(){
            $('.icoTop1').css("display","none");
        });
        $('.img1-2').mouseover(function(){
    	    $('.icoTop2').css("display","block");
            }).mouseout(function(){
    	    $('.icoTop2').css("display","none");
        });
        $('.img1-3').mouseover(function(){
    	    $('.icoTop3').css("display","block");
            }).mouseout(function(){
    	    $('.icoTop3').css("display","none");
        });
        $('.img1-4').mouseover(function(){
    	    $('.icoTop4').css("display","block");
            }).mouseout(function(){
    	    $('.icoTop4').css("display","none");
        });
        //poem切换
        $('h3').click(function(){
		    $(this).addClass('.sentence-contain h3-1').siblings().removeClass();
	    });//背景颜色变换
	    $('h3').click(function(){
		    $(this).next('ul').slideToggle().siblings('ul').slideUp();
	    });//诗歌内容滑出及隐藏
        //下方图片左右变换
   		$(".after1").click(function(){
            $self = $('.move');
            $self.stop().animate({"margin-left" : -180 +"px"},500 , function(){
            $self.css({"margin-left":"0px"}).find("li:first").appendTo($self);
            });
        });//右侧箭头控制每次移动一个图片距离
        $(".before1").click(function(){
            $self = $('.move');
            $self.css({"margin-left" : -180 +"px"}).find("li:last").prependTo($self);
            $self.stop().animate({"margin-left" : "0px"},500 , function(){});
        });//左侧箭头控制每次移动一个图片距离
        //放大图片隐藏
        $('.popWindow1').hide();
	    $('.popWindow2').hide();
	    $('.popWindow3').hide();
	    $('.popWindow4').hide();
        //对应点击图片变量
	    var oBtn1=$('#show1');
	    var oBtn2=$('#show2');
	    var oBtn3=$('#show3');
	    var oBtn4=$('#show4');
	    //设置对应变量
	    var popWindow1=$('.popWindow1');
	    var popWindow2=$('.popWindow2');
	    var popWindow3=$('.popWindow3');
	    var popWindow4=$('.popWindow4');
	    //设置关闭按钮
	    var oClose1=$('.popWindow1 span');
	    var oClose2=$('.popWindow2 span');
	    var oClose3=$('.popWindow3 span');
	    var oClose4=$('.popWindow4 span');
	    //获取显示器宽度及高度
	    var browerWidth=$(window).width();
	    var browerHeight=$(window).height();
	    //滑动条高度
	    var browserScrollTop=$(window).scrollTop();
        //显示居中
	    var popWindowWidth1=popWindow1.outerWidth(true);
	    var popWindowHeight1=popWindow1.outerHeight(true);
	    var positionLeft1=browerWidth/2-popWindowWidth1/2;
	    var positionTop1=browerHeight/2-popWindowHeight1/2+browserScrollTop;

	    var popWindowWidth2=popWindow2.outerWidth(true);
	    var popWindowHeight2=popWindow2.outerHeight(true);
	    var positionLeft2=browerWidth/2-popWindowWidth2/2;
	    var positionTop2=browerHeight/2-popWindowHeight2/2+browserScrollTop;

	    var popWindowWidth3=popWindow3.outerWidth(true);
	    var popWindowHeight3=popWindow3.outerHeight(true);
	    var positionLeft3=browerWidth/2-popWindowWidth3/2;
	    var positionTop3=browerHeight/2-popWindowHeight3/2+browserScrollTop;

    	var popWindowWidth4=popWindow4.outerWidth(true);
	    var popWindowHeight4=popWindow4.outerHeight(true);
	    var positionLeft4=browerWidth/2-popWindowWidth4/2;
	    var positionTop4=browerHeight/2-popWindowHeight4/2+browserScrollTop;
        //点击第一个图片，图片变大
	    oBtn1.click(function(){
		    popWindow1.show().animate({
			'left':positionLeft1+'px',
			'top':positionTop1+'px'
		    },500).dequeue();
    	});
    	//点击第二个图片，图片变大
	    oBtn2.click(function(){
		    popWindow2.show().animate({
			'left':positionLeft2+'px',
			'top':positionTop2+'px'
		    },500).dequeue();
	    });
	    //点击第三个图片，图片变大
	    oBtn3.click(function(){
		    popWindow3.show().animate({
			'left':positionLeft3+'px',
			'top':positionTop3+'px'
	    	},500).dequeue();
	    });
	    //点击第四个图片，图片变大
	    oBtn4.click(function(){
		    popWindow4.show().animate({
			'left':positionLeft4+'px',
			'top':positionTop4+'px'
		    },500).dequeue();
    	});
    	//获取显示器相关数据
	    $(window).resize(function(){
		    browerWidth=$(window).width();
		    browerHeight=$(window).height();

		    positionLeft1=browerWidth/2-popWindowWidth1/2;
		    positionTop1=browerHeight/2-popWindowHeight1/2+browserScrollTop;

		    positionLeft2=browerWidth/2-popWindowWidth2/2;
		    positionTop2=browerHeight/2-popWindowHeight2/2+browserScrollTop;

		    positionLeft3=browerWidth/2-popWindowWidth3/2;
		    positionTop3=browerHeight/2-popWindowHeight3/2+browserScrollTop;

		    positionLeft4=browerWidth/2-popWindowWidth4/2;
		    positionTop4=browerHeight/2-popWindowHeight4/2+browserScrollTop;

		    popWindow1.animate({
			    'left':positionLeft1+'px',
			    'top':positionTop1+'px'
		    },500).dequeue();
		    popWindow2.animate({
			    'left':positionLeft2+'px',
			    'top':positionTop2+'px'
	    	},500).dequeue();
		    popWindow3.animate({
			    'left':positionLeft3+'px',
			    'top':positionTop3+'px'
		    },500).dequeue();
		    popWindow4.animate({
			    'left':positionLeft4+'px',
			    'top':positionTop4+'px'
		    },500).dequeue();
	    });
	    $(window).scroll(function(){
		    browserScrollTop=$(window).scrollTop();

		    positionTop1=browerHeight/2-popWindowHeight1/2+browserScrollTop;
		    positionTop2=browerHeight/2-popWindowHeight2/2+browserScrollTop;  
		    positionTop3=browerHeight/2-popWindowHeight3/2+browserScrollTop;
		    positionTop4=browerHeight/2-popWindowHeight4/2+browserScrollTop;
		    popWindow1.animate({
			    'left':positionLeft1+'px',
			    'top':positionTop1+'px'
		    },500).dequeue();
		    popWindow2.animate({
			    'left':positionLeft2+'px',
			    'top':positionTop2+'px'
		    },500).dequeue();
		    popWindow3.animate({
			    'left':positionLeft3+'px',
			    'top':positionTop3+'px'
		    },500).dequeue();
		    popWindow4.animate({
			    'left':positionLeft4+'px',
			    'top':positionTop4+'px'
		    },500).dequeue();
	    });
        //关闭按钮
	    oClose1.click(function(){
		    popWindow1.hide();
	    });
	    oClose2.click(function(){
		    popWindow2.hide();
    	});
	    oClose3.click(function(){
		    popWindow3.hide();
    	});
	    oClose4.click(function(){
		    popWindow4.hide();
    	});
});