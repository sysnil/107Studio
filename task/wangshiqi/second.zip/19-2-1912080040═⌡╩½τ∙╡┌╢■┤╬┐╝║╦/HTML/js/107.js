$(document).ready(function(){
	$(".p1").mouseenter(function(){
	   	$(".ul1").slideDown("fast");
		$(".p1").css("background-color","#EC6B0E");
		});
	$(".p1").mouseleave(function(){
	   	$(".ul1").slideUp("fast");
		$(".p1").css("background-color","#01ACB7");
		});
	$(".p2").mouseenter(function(){
		$(".ul2").slideDown("fast");
		$(".p2").css("background-color","#EC6B0E");
		});
	$(".p2").mouseleave(function(){
		$(".ul2").slideUp("fast");
		$(".p2").css("background-color","#01ACB7");
		});
	$(".p3").mouseenter(function(){
		$(".ul3").slideDown("fast");
		$(".p3").css("background-color","#EC6B0E");
		});
	$(".p3").mouseleave(function(){
		$(".ul3").slideUp("fast");	
		$(".p3").css("background-color","#01ACB7");
		});
	$(".p4").mouseenter(function(){
		$(".ul4").slideDown("fast");
		$(".p4").css("background-color","#EC6B0E");
		});
	$(".p4").mouseleave(function(){
		$(".ul4").slideUp("fast");	
		$(".p4").css("background-color","#01ACB7");
		});
	$(".p5").mouseenter(function(){
		$(".ul5").slideDown("fast");
		$(".p5").css("background-color","#EC6B0E");
		});
	$(".p5").mouseleave(function(){
		$(".ul5").slideUp("fast");
		$(".p5").css("background-color","#01ACB7");
        });
		$(".p0").mouseenter(function(){
			$(".p0").css("background-color","#EC6B0E");
			});
		$(".p0").mouseleave(function(){
			$(".p0").css("background-color","#01ACB7");
		    });
		$(".p6").mouseenter(function(){
			$(".p6").css("background-color","#EC6B0E");
				});
		$(".p6").mouseleave(function(){
			$(".p6").css("background-color","#01ACB7");
			    });
		$('.ul1 > li').mouseenter(function(){
			$(this).css("background-color","#EC6B0E");
				});
		$('.ul1>li').mouseleave(function(){
			$(this).css("background-color","#01ACB7");
			    });
		$(".b1 ").mouseenter(function(){
			$(".b1 > li").css("background-color","red");
			});
		$(".b1 > a").mouseleave(function(){
			$(".b1 > a").css("color","black");
		    });
		
		
		$(".but1").click(function(){
			$(".b1").show();
			$(".but1").css("background-color","#EC6B0E");
			$(".b2").hide();
			$(".but2").css("background-color","#F5AA02");
			});
		$(".but2").click(function(){
			$(".b2").show();
			$(".but2").css("background-color","#EC6B0E");
			$(".b1").hide();
			$(".but1").css("background-color","#F5AA02");
			});	
			//搜索栏
		
			//banner轮播
			var $middle = $(".middle");
			var $list = $(".list");
			var $prev = $(".prev");
			var $next = $(".next");
			var PAGE_WIDTH = 1342;//宽度
			var TIME = 400;//翻页的持续时间
			var ITEM_TIME = 20;//单元移动的间隔时间
			var imgCount = 4;
			$prev.click(function(){
				nextPage(false);
				});
			$next.click(function(){
				nextPage(true);
				});
			function nextPage (next) {
				var currLeft = $list.position().left;
				var offset = 0;
				offset = next ? -PAGE_WIDTH : PAGE_WIDTH;
				cssLeft = currLeft+offset;
				if(cssLeft=== -(imgCount+1) * PAGE_WIDTH){
					cssLeft = -PAGE_WIDTH;
				}else if(cssLeft=== 0){
					cssLeft = -imgCount * PAGE_WIDTH;
				}
				$list.css("left",cssLeft);
			}
			var interval = setInterval(nextPage,2500);
			
			$(".middle, .prev, .next").hover(function(){
			     stop();
				$(".prev, .next").show();
				}, function(){
				$(".prev, .next").hide();
				
			});
			//诗歌动画
			$(".pbut1").click(function(){
				$(".poem1").slideDown("fast");
				$(".pbut1").css("background-color","#EC6B0E");
				$(".pbut2, .pbut3").css("background-color","#F5AA02");
				$(".poem2, .poem3").slideUp("fast");
				$(".pbut2").animate({top:"230px"});
				$(".pbut3").animate({top:"265px"});
				});
			$(".pbut2").click(function(){
				$(".poem2").slideDown("fast");
				$(".pbut2").css("background-color","#EC6B0E");
				$(".pbut1, .pbut3").css("background-color","#F5AA02");
				$(".poem1, .poem3").slideUp("fast");
				$(".pbut2").animate({top:"35px"});
				$(".pbut3").animate({top:"265px"});
				});
				$(".pbut3").click(function(){
					$(".poem3").slideDown("fast");
					$(".pbut3").css("background-color","#EC6B0E");
					$(".pbut1, .pbut2").css("background-color","#F5AA02");
					$(".poem1, .poem2").slideUp("fast");
					$(".pbut2").animate({top:"35px"});
					$(".pbut3").animate({top:"70px"});
					});
				
				
			//图片轮播
			var page_width = 200;//宽
			var ImgCount = 6;
			
			$("#prev").click(function(){
				NextPage(false);
				});
			$("#next").click(function(){
				NextPage(true);
				});
			function NextPage (next) {
				var currleft = $("#box").position().left;
				var Offset = 0;
				Offset = next ? -page_width : page_width;
				CssLeft = currleft+Offset;
				if(CssLeft=== -(ImgCount-1) * page_width){
					CssLeft = 0;
				}else if(CssLeft=== 0){
					CssLeft =-(ImgCount-1) *page_width;
				}
				$("#box").css("left",CssLeft);
			}	
			var nexterval = setInterval(NextPage,2500);
			//会议照片
			$(".Smet1").click(function(){
				$(".Bmet1, .topt1").show();
				$(".Bmet2, .topt2").hide();
				$(".Bmet3, .topt3").hide();
				$(".Bmet4, .topt4").hide();
				});	
			$(".Smet2").click(function(){
				$(".Bmet2, .topt2").show();
				$(".Bmet1, .topt1").hide();
				$(".Bmet3, .topt3").hide();
				$(".Bmet4, .topt4").hide();
				});
			$(".Smet3").click(function(){
				$(".Bmet3, .topt3").show();
				$(".Bmet2, .topt2").hide();
				$(".Bmet1, .topt1").hide();
				$(".Bmet4, .topt4").hide();
				});
			$(".Smet4").click(function(){
				$(".Bmet4, .topt4").show();
				$(".Bmet1, .topt1").hide();
				$(".Bmet2, .topt2").hide();
				$(".Bmet3, .topt3").hide();
				});	
			var PAGE_width = 410;//宽度
			var imgcount =4;
			function nextpage (next) {
				var CurrLeft = $(".bigmet").position().left;
				var OffSet = 0;
				OffSet = next ? -PAGE_width :  PAGE_width;
				cssleft = CurrLeft+OffSet;
				if(cssleft=== -(imgcount+1) * PAGE_width){
					cssleft = -PAGE_width;
				}else if(cssleft=== 0){
					cssleft = -imgcount * PAGE_width;
				}
				$(".bigmet").css("left",cssleft);
			}			
			var startmove = setInterval(nextpage,2500);
		//dog效果//
		$(".close").click(function(){
			$(".Bdog1").hide();
			$(".Bdog2").hide();
			$(".Bdog3").hide();
			$(".Bdog4").hide();
			$(".close").hide();
			});	
	    $(".dog1").click(function(){
		    $(".Bdog1").show();
		    $(".Bdog2").hide();
		    $(".Bdog3").hide();
		    $(".Bdog4").hide();
		    $(".close").show();
		    });	
		$(".dog2").click(function(){
			$(".Bdog2").show();
			$(".Bdog1").hide();
			$(".Bdog3").hide();
			$(".Bdog4").hide();
			$(".close").show();
			});	
		$(".dog3").click(function(){
			$(".Bdog1").hide();
			$(".Bdog2").hide();
			$(".Bdog3").show();
			$(".Bdog4").hide();
			$(".close").show();
			});
		$(".dog4").click(function(){
			$(".Bdog4").show();
			$(".Bdog2").hide();
			$(".Bdog3").hide();
			$(".Bdog1").hide();
			$(".close").show();
			});	
  
   
   
   
   
   
});