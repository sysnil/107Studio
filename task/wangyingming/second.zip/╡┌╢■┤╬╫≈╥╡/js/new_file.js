// 
$(document).ready(function(){
	$(".searchconcent input").click(function(){
		if($(".searchconcent input").hasClass("white"))
		{
			$(".searchconcent input").removeClass("white");
		}
		else
		{
			$(".searchconcent input").addClass("white");
		}
		$(".searchconcent input").mouseleave(function(){
			$(".searchconcent input").removeClass("white");
		});
	});
});
// 下拉菜单
 $(document).ready(function() {
 	$(".show>li").mouseenter(function() {
 		$(this).children("ul").children("li").stop(); //停止在当前的正在运行的动画，防止连续多次划入划出后动画不停止
 		$(this).children("ul").children("li").slideDown(300).css("z-index", 10);
 	});
 	$(".show>li").mouseleave(function() {
 		$(this).children("ul").children("li").stop();
 		$(this).children("ul").children("li").slideUp(80);
 	});
 });
 //banner .bannerimgs li      #goprev  #gonext  图片轮播
 var i = 0;
 var sum = 3;
 var stop = null;

 function circle() {
 	$(".banner .bannerimgs li").eq(i).fadeIn().siblings().fadeOut();
 	$(".banner .dot li").eq(i).addClass("dotcolorone").removeClass("dotcolortwo").siblings().removeClass("dotcolorone").addClass(
 		"dotcolortwo");
 }

 function auto() {
 	stop = setInterval(function() {
 		i++;
 		if (4 == i) {
 			i = 0;
 		}
 		circle();
 	}, 3000);
 }
 $(document).ready(function() {
 	$(".banner .bannerimgs li").eq(0).show();
 	auto();

 	$(".banner .dot li").click(function() {
 		clearInterval(stop);
 		i = $(this).index();
 		circle();
 		auto();
 	});

 	$("#gopre").click(function() {
 		clearInterval(stop);
 		i--;
 		if (i == -1) {
 			i = 3;
 		}
 		circle();
 		auto();
 	});
 	$("#gonext").click(function() {
 		clearInterval(stop);
 		i++;
 		if (i == 4) {
 			i = 0;
 		}
 		circle();
 		auto();
 	});
 });
 //left texttitle  text  poem  data  切换
 var k = 0;
 $(document).ready(function() {
 	$(".texttitle li").click(function() {
 		$(this).removeClass("titlecolortwo").addClass("titlecolorone").siblings().addClass("titlecolortwo").removeClass(
 			"titlecolorone");
 		k = $(this).index();
 		$(".text div").eq(k).removeClass("hide").siblings().addClass("hide");
 	});
 });
 //图片
 var j = 0;
 var st = null;

 function circle2() {
 	$(".center .above li").eq(j).fadeIn().siblings().fadeOut();
 	$(".center .blow li").eq(j).addClass("border").siblings().removeClass("border");
 }

 function auto2() {
 	st = setInterval(function() {
 		j++;
 		if (4 == j) {
 			j = 0;
 		}
 		circle2();
 	}, 3000);
 }

 $(document).ready(function() {
 	$(".center ul li").eq(0).show();
 	auto2();

 	$(".center .blow li").click(function() {
 		clearInterval(st);
 		j = $(this).index();
 		circle2();
 		auto2();
 	});
 });
 //下拉展示面板
 $(document).ready(function() {
 	$(".poemconcent span").click(function() {
 		$(this).addClass("titlecolorone").removeClass("titlecolortwo");
 		$(this).parent().parent().siblings().children("li").children("span").addClass("titlecolortwo").removeClass(
 			"titlecolorone");
 		$(this).parent().parent().siblings().children("li").children("ul").addClass("poemhide");
 		$(this).siblings().removeClass("poemhide");
 	});
 });
 //图片 dogs
 var stationary=0;
 var ting=null;
 function auto3() {
 	ting = setInterval(function() {
 		stationary=stationary+250;
 		if(stationary>=1500)
 		{
 			stationary=0;
 		}
 		$(".fourimgs ul").css("marginLeft",-stationary);
 	}, 3000);
 }
$(document).ready(function(){
	auto3();
	$(".fourimgs #left").click(function(){
		clearInterval(ting);
		stationary=stationary-250;
		if(stationary<0)
		{
			stationary=1250;
		}
		$(".fourimgs ul").css("marginLeft",-stationary);
		auto3();
	});
	$("#right").click(function(){
		clearInterval(ting);
		stationary=stationary+250;
		if(stationary>1500)
		{
			stationary=0;
		}
		$(".fourimgs ul").css("marginLeft",-stationary);
		auto3();
	});
 });
// 弹出图片
$(function(){
	$(".fourdogs ul li").click(function(){
		var marked=$(this).index();
		$(".layermask").show();
		$(".bouncediv").show();
		$(".bouncediv").children("img").eq(marked).removeClass("clsl");
		$(".close").click(function(){
			$(".bouncediv").children("img").eq(marked).addClass("clsl");
			$(".bouncediv").hide();
			$(".layermask").hide();
		});
	});
});
