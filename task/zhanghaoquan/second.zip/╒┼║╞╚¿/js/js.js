
$(function () {


    /* Header and Menu Start*/

    $("input").mouseover(function () {  
        this.style.backgroundColor = 'white'
    })
    .mouseout(function () {  
        this.style.backgroundColor = '#F5AA02'
    });
    $(".menu li").mouseover(function () {  
        this.style.backgroundColor = '#EC6B0E';
    })
    .mouseout(function () {  
        this.style.backgroundColor = '#01ACB7'
    })
    $(".menumainpart>li").hover(function () {  
        $(this).children().stop().slideToggle()
    });
    $(".menumainpart>li>ul>li").css("border","1px solid gray");
    /* Header and Menu End*/


    /* Middle Pic Start */
    var leftBn,rightBn,piclist,lilist,preli;
    var position = 0;
    init();
    function init() {  
        leftBn=document.getElementById("leftBn")
        rightBn=document.getElementById("rightBn");
        piclist=document.getElementById("piclist");
        lilist=Array.from(document.getElementById("pic-num-main").children);
        leftBn.addEventListener("click",clickHandler);
        rightBn.addEventListener("click",clickHandler);
        for(var i=0;i<lilist.length;i++){
            lilist[i].addEventListener("click",liclickhandler);
        }
        preli=lilist[0];
        imgconMove();
    }

    function liclickhandler() {  
        position=lilist.indexOf(this);
        imgconMove();
    }

    function clickHandler() {  
        if(this===leftBn){
            position--;
            if(position<0){
                position=3;
            }
            imgconMove();
            return;
        }
        position++;
        if(position>3){
            position=0;
        }
        imgconMove();
    }
    
    function imgconMove() {  
        piclist.style.left=-100*position+"%";
        if(preli){
            preli.style.backgroundColor = "grey";
        }
        preli=lilist[position];
        preli.style.backgroundColor="#EC6B0E";
    }
    /* Middle Pic End*/


    /* Content Start*/
    $("#contentlefttopright").click(function () {
        $("#Text2").fadeIn(500);
        $("#Text1").fadeOut(0);
        this.style.backgroundColor = '#EC6B0E';
        $("#contentlefttopleft").css("backgroundColor","#F5AA02")
    });
    $("#contentlefttopleft").click(function () {
        $("#Text1").fadeIn(500); 
        $("#Text2").fadeOut(0);
        this.style.backgroundColor = '#EC6B0E';
        $("#contentlefttopright").css("backgroundColor","#F5AA02")
    })
    $("#Text2").css("display","none");

    var numberimg=$("#contentmiddleimgcon img").length;
    var index1=0;
    $("#middleimgtopcon img:gt(0)").css("visibility","hidden");
    $("#contentmiddlep p:gt(0)").css("visibility","hidden");
    $("#contentmiddleimgcon img:eq(0)").css("border-color","#EC6B0E");
    $("#contentmiddleimgcon img:eq(0)").click(function () {
        index1=0;  
        $("#contentmiddleimg").animate({left:0},240)
        $("#middleimgtopcon img:eq(0)").css("visibility","visible");
        $("#middleimgtopcon img:gt(0)").css("visibility","hidden");
        $("#contentmiddlep p:eq(0)").css("visibility","visible");
        $("#contentmiddlep p:gt(0)").css("visibility","hidden");
        $("#contentmiddleimgcon img:gt(0)").css("border-color","#C9DDE6");
        $("#contentmiddleimgcon img:eq(0)").css("border-color","#EC6B0E");
    })
    $("#contentmiddleimgcon img:eq(1)").click(function () {
        index1=1;  
        $("#contentmiddleimg").animate({left:-390},240)
        $("#middleimgtopcon img:eq(1)").css("visibility","visible");
        $("#middleimgtopcon img:eq(1)").siblings().css("visibility","hidden");
        $("#contentmiddlep p:eq(1)").css("visibility","visible");
        $("#contentmiddlep p:eq(1)").siblings().css("visibility","hidden");
        $("#contentmiddleimgcon img:eq(1)").css("border-color","#EC6B0E");
        $("#contentmiddleimgcon img:eq(1)").siblings().css("border-color","#C9DDE6");
    })
    $("#contentmiddleimgcon img:eq(2)").click(function () {  
        index1=2;
        $("#contentmiddleimg").animate({left:-780},240);
        $("#middleimgtopcon img:eq(2)").css("visibility","visible");
        $("#middleimgtopcon img:eq(2)").siblings().css("visibility","hidden");
        $("#contentmiddlep p:eq(2)").css("visibility","visible");
        $("#contentmiddlep p:eq(2)").siblings().css("visibility","hidden");
        $("#contentmiddleimgcon img:eq(2)").css("border-color","#EC6B0E");
        $("#contentmiddleimgcon img:eq(2)").siblings().css("border-color","#C9DDE6");
    })
    $("#contentmiddleimgcon img:eq(3)").click(function () { 
        index1=3; 
        $("#contentmiddleimg").animate({left:-1170},240);
        $("#middleimgtopcon img:eq(3)").css("visibility","visible");
        $("#middleimgtopcon img:eq(3)").siblings().css("visibility","hidden");
        $("#contentmiddlep p:eq(3)").css("visibility","visible");
        $("#contentmiddlep p:eq(3)").siblings().css("visibility","hidden");
        $("#contentmiddleimgcon img:eq(3)").css("border-color","#EC6B0E");
        $("#contentmiddleimgcon img:eq(3)").siblings().css("border-color","#C9DDE6");
    })
    setInterval(function () {  
        index1++;
        if(index1==numberimg){
            index1=0;
        }
        $("#contentmiddleimg").animate({left:-390*index1},240);
        if(index1==0){
            $("#middleimgtopcon img:eq(0)").css("visibility","visible");
            $("#middleimgtopcon img:gt(0)").css("visibility","hidden");
            $("#contentmiddlep p:eq(0)").css("visibility","visible");
            $("#contentmiddlep p:gt(0)").css("visibility","hidden");
            $("#contentmiddleimgcon img:gt(0)").css("border-color","#C9DDE6");
            $("#contentmiddleimgcon img:eq(0)").css("border-color","#EC6B0E");
        }
        if(index1==1){
            $("#middleimgtopcon img:eq(1)").css("visibility","visible");
            $("#middleimgtopcon img:eq(1)").siblings().css("visibility","hidden");
            $("#contentmiddlep p:eq(1)").css("visibility","visible");
            $("#contentmiddlep p:eq(1)").siblings().css("visibility","hidden");
            $("#contentmiddleimgcon img:eq(1)").css("border-color","#EC6B0E");
            $("#contentmiddleimgcon img:eq(1)").siblings().css("border-color","#C9DDE6");
        }
        if(index1==2){
            $("#middleimgtopcon img:eq(2)").css("visibility","visible");
            $("#middleimgtopcon img:eq(2)").siblings().css("visibility","hidden");
            $("#contentmiddlep p:eq(2)").css("visibility","visible");
            $("#contentmiddlep p:eq(2)").siblings().css("visibility","hidden");
            $("#contentmiddleimgcon img:eq(2)").css("border-color","#EC6B0E");
            $("#contentmiddleimgcon img:eq(2)").siblings().css("border-color","#C9DDE6");
        }
        if(index1==3){
            $("#middleimgtopcon img:eq(3)").css("visibility","visible");
            $("#middleimgtopcon img:eq(3)").siblings().css("visibility","hidden");
            $("#contentmiddlep p:eq(3)").css("visibility","visible");
            $("#contentmiddlep p:eq(3)").siblings().css("visibility","hidden");
            $("#contentmiddleimgcon img:eq(3)").css("border-color","#EC6B0E");
            $("#contentmiddleimgcon img:eq(3)").siblings().css("border-color","#C9DDE6");
        }
    },2000);
    
    $(".content-right>li>div:gt(0)").css("display","none");
    $(".righttexttitle:eq(0)").click(function () {  
        $(this).next().slideToggle(400);
        $(this).css("backgroundColor","#EC6B0E")
        $(".righttexttitle:gt(0)").next().slideUp(400);
        $(".righttexttitle:eq(1)").css("backgroundColor","#F5AA02");
        $(".righttexttitle:eq(2)").css("backgroundColor","#F5AA02");
    })
    $(".righttexttitle:eq(1)").click(function () {  
        $(this).next().slideToggle(400);
        $(this).css("backgroundColor","#EC6B0E")
        $(".righttexttitle:eq(0)").next().slideUp(400);
        $(".righttexttitle:eq(2)").next().slideUp(400);
        $(".righttexttitle:eq(0)").css("backgroundColor","#F5AA02");
        $(".righttexttitle:eq(2)").css("backgroundColor","#F5AA02");
    })
    $(".righttexttitle:eq(2)").click(function () {  
        $(this).next().slideToggle(400);
        $(this).css("backgroundColor","#EC6B0E")
        $(".righttexttitle:eq(0)").next().slideUp(400);
        $(".righttexttitle:eq(1)").next().slideUp(400);
        $(".righttexttitle:eq(0)").css("backgroundColor","#F5AA02");
        $(".righttexttitle:eq(1)").css("backgroundColor","#F5AA02");
    })
    /* Content End */

    
    /* ContentPic Start */
    $(".contentpicroll img:lt(11)").css("margin-right","10px");
    var index3=0;
    $("#rollBtnRight").click(function () {  
        next();
    })
    $("#rollBtnLeft").click(function () {  
        prev();
    })
    setInterval(function () {  
        index3++;
        if(index3==9){
            index3=0;
        }
        $(".contentpicroll").animate({left:-index3*205},140);
    },2500)
    function next() {  
        index3++;
        if(index3 > 8){
            index3 = 0;
            $(".contentpicroll").animate({left:-index3*205},140);
        }
        $(".contentpicroll").animate({left:-index3*205},140);
    }
    function prev() {  
        index3--;
        if(index3<0){
            index3 = 8;
            $(".contentpicroll").animate({left:-index3*205},140);
        }
        $(".contentpicroll").animate({left:-index3*205},140);
    }
    
    relHeight =document.documentElement.scrollHeight;
    document.getElementById('cover').style.height = relHeight+'px';
    $(".contentdog img").click(function () { 
        $("#cover").css("display","block");
    })
    $(".contentdog img:eq(0)").click(function () {  
        $(".bigimg img:eq(0)").fadeIn(500);
        $(".bigimg img:eq(0)").siblings().css("display","none");
        $(".outerdiv").fadeIn(500);
        $(".bigimgwrap").fadeIn(500);
    })
    $(".contentdog img:eq(1)").click(function () {  
        $(".bigimg img:eq(1)").fadeIn(500);
        $(".bigimg img:eq(1)").siblings().css("display","none");
        $(".outerdiv").fadeIn(500);
    })
    $(".contentdog img:eq(2)").click(function () {  
        $(".bigimg img:eq(2)").fadeIn(500);
        $(".bigimg img:eq(2)").siblings().css("display","none");
        $(".outerdiv").fadeIn(500);
    })
    $(".contentdog img:eq(3)").click(function () {  
        $(".bigimg img:eq(3)").fadeIn(500);
        $(".bigimg img:eq(3)").siblings().css("display","none");
        $(".outerdiv").fadeIn(500);
    })
    $("#close").click(function () {  
        $(".outerdiv").css("display","none");
        $(".bigimg img").css("display","none");
        $("#cover").css("display","none");
        $(".bigimgwrap").css("display","none");
    })
    /* ContentPic End */ 
})