$(function (){
		//鼠标移入搜索框，背景颜色改变
		$('.form').on({
			mouseover:function(){
				$(this).css('background-color','white');
			},
			mouseout:function(){
				$(this).css('background-color','rgb(250,153,2)');
			}
		});
		var lis = $('.sizein>li');
		//给一级菜单设置鼠标移入事件，显示二级菜单
		$('.sizeout>li').on({
		mouseover:function(){
			$(this).children('.sizein').show();
			$(this).css('background-color','rgb(250,113,13)');
		},
		mouseout:function(){
			$(this).children('.sizein').hide();
			$(this).css('background-color','rgb(36,174,188)');
		}
        });
        $(lis).on({
        	mouseover:function(){
        		$(this).css('background-color','rgb(250,113,13)');
        	},
        	mouseout:function(){
        		$(this).css('background-color','rgb(36,174,188)');
        	}
        });
        $('#top>li').click(function(){
           var idx = $(this).index();
           console.log(idx);
           $('#center>li').eq(idx).show().siblings('li').hide();
           $(this).css('background-color','rgb(250,113,13)');
           $(this).siblings('li').css('background-color','rgb(250,153,2)');  
        });
        $('.poem>li>a').on({
        	mouseover:function(){
               $(this).css('color','red').parent('li').next('li').children('a').css('color','red');
           },
            mouseout:function(){
               $(this).css('color','black').parent('li').next('li').children('a').css('color','black');
           }

        });
        //平滑翻页轮播图
        var i = 0;
        var first = $('.img>li').first().clone();
        $('.img').append(first);
        $('.move>li:nth-of-type(2)').click(function(){
            i++;
            if(i == 5){
                $('.img').css({left:'0px'});
                i = 1;
            }
            $('.img').animate({left:-i*100+'%'});
            if(i == 4){
                $('.num>li').eq(0).addClass('on').siblings().removeClass('on');
            }else{
            $('.num>li').eq(i).addClass('on').siblings().removeClass('on');
            }
        });
        $('.move>li:nth-of-type(1)').click(function(){
            i--;
            if(i == -1){
                $('.img').css({left:-3*100+'%'});
                i = 3;
            }
            $('.img').animate({left:-i*100+'%'});
            $('.num>li').eq(i).addClass('on').siblings().removeClass('on');
        });
        //实现图片自动轮播
        var timer = setInterval(function(){
              i++;
            if(i == 5){
                $('.img').css({left:'0px'});
                i = 1;
            }
            $('.img').animate({left:-i*100+'%'});
            if(i == 4){
                $('.num>li').eq(0).addClass('on').siblings().removeClass('on');
            }else{
            $('.num>li').eq(i).addClass('on').siblings().removeClass('on');
            }
        },2000);
        //鼠标移入动画停止
        $('.screen').mouseover(function(){
            clearInterval(timer);
        });
        $('.screen').mouseout(function(){
            timer = setInterval(function(){
            i++;
            if(i == 5){
                $('.img').css({left:'0px'});
                i = 1;
            }
            $('.img').animate({left:-i*100+'%'});
            if(i == 4){
                $('.num>li').eq(0).addClass('on').siblings().removeClass('on');
            }else{
            $('.num>li').eq(i).addClass('on').siblings().removeClass('on');
            }
        },2000);
        });
        //点击圆点跳转
        $('.num>li').click(function(){
            i = $(this).index();
            if(i == 0 && $('.img').css('left') == '-400%'){

            }else{
            $('.img').animate({left:-i*100+'%'});
            $('.num>li').eq(i).addClass('on').siblings().removeClass('on');
            }
        });
        //总偏移量为100%*4；
        //给小图片设置点击事件，让id为img修改src为大图路径，让p标签文本设置为对应的文字；
        //让id为des这个p标签的文本设置为当前点击的这个a标签所对应的title;
        $('#meetings>li>a').click(function(){
             var srcValue = $(this).attr('href');
             var contentValue = $(this).attr('title');
             var arrows = $('#arrow>ul>li');
             var style1 = $(this).children('img');
             var style2 = $(this).parent('li').siblings('li').children('a').children('img');
             let index = $(this).parent('li').index();
             var other = $(arrows).eq(index);
             $(other).children('img').show();
             $(other).siblings('li').children('img').hide();
             $('#image').attr('src',srcValue);
             $('#des').text(contentValue);
             $(style1).css('border-style','solid').css('border-width','2px').css('border-color','rgb(250,113,13)');
             $(style2).css('border-style','solid').css('border-width','2px').css('border-color','rgb(222,242,244)');
             //阻止a标签的跳转
             return false;
        });
        //点击标题li，对应div显示，其兄弟标签li对应的div隐藏
        $('.parentWrap>.menuGroup').click(function(){
             $(this).children('div').show().parent().siblings('li').children('div').hide();
             $(this).children('span').css('background-color','rgb(250,113,13)').parent('li').siblings('li').children('span').css('background-color','rgb(250,153,2)');
        });
        //平滑翻页；
        var j = 0;
        var picture1 = $('.imgGroup>li').first().clone();
        $('.imgGroup').append(picture1);
        $('.moving>li:nth-of-type(2)').click(function(){
            j++;
            if(j == 4){
                $('.imgGroup').css({left:'0px'});
                j = 1;
            }
            $('.imgGroup').animate({left:-j*25+'%'});
        });
        $('.moving>li:nth-of-type(1)').click(function(){
            j--;
            if(j == -1){
                $('.imgGroup').css({left:-5*25+'%'});
                j = 3;
            }
            $('.imgGroup').animate({left:-j*25+'%'});
        });
        //自动翻页
        var timer1 = setInterval(function(){
            j++;
            if(j == 4){
                $('.imgGroup').css({left:'0px'});
                j = 1;
            }
            $('.imgGroup').animate({left:-j*25+'%'});
        },2000);
        //鼠标移入动画停止
        $('.imgGroup').mouseover(function(){
            clearInterval(timer1);
        });
        $('.imgGroup').mouseout(function(){
            timer1 = setInterval(function(){
                j++;
            if(j == 4){
                $('.imgGroup').css({left:'0px'});
                j = 1;
            }
            $('.imgGroup').animate({left:-j*25+'%'});
        },2000);
        });
        //点击图片实现放大
        $(document).ready(function() {
            $(".img_min").click(function(){
                var _this = $(this);//将当前的min_img元素作为_this传入函数
                imgShow(".outerdiv", ".img_max", _this);
            });
        });
        function imgShow(outerdiv, img_max, _this){
                var imgSrc = _this.attr("src");       //获取当前点击的min_img元素中的src属性
                $(".img_max").attr("src", imgSrc);    //设置max_img元素的src属性
                    $('#outerdiv').fadeIn("fast");
                    $('.close').show();          //淡入显示#outerdiv及.pimg
                }
                $('.close').click(function(){           //再次点击淡出消失弹出层
                    $('#outerdiv').fadeOut("fast");
                    $(this).hide();
                });
        //鼠标移入字体变色
        $('.support>a').on({
        mouseover:function(){
			$(this).css('color','red');
		},
		mouseout:function(){
			$(this).css('color','black');
		}
        });
        $('#floatwindow').on({
            mouseover:function(){
                $(this).animate({
                    left:800,
                    top:200
                }3000,'swing');
            }
        });
	});