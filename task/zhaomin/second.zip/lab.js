
$(function(){
	            //导航栏         		
	          	var a= $('.ul1>li');
	          	$(".box1>a").css("background-color","#009BBC");
	          	a.mouseover(function(){
	          		  var index1=$(this).index();
	          		  var n=120*index1; 
	          	$(".box1").css("left", ""+n+"px");
                 });
	          	a.mouseover(function () {
	          		$(this).children('.box1').show();
	          		$(this).children("a").css("background-color","#EC6B0E");
	          	});
	          	a.mouseout(function () {
	          		$(this).children('.box1').hide();
	          		$(this).children("a").css("background-color","#009BBC");
	          	});
	          	
	          	$(".box1>a").mouseover(function(){
	          		$(this).css("background-color","#EC6B0E");
	          	});
	          	$(".box1>a").mouseout(function(){
	          		$(this).css("background-color","#009BBC");
	          	});
	          	
	          		
	          	$("input").click(function(){
	          		$(this).css("background-color","white");
	          	})
	          	$("input").mouseout(function(){
	          		$(this).css("background-color","transparent");
	          	})
	          	
	          //top2图片轮播
	          var time1=0;
              var time2=0;
              var timeId3;
              $(".btn2 li").eq(0).css({
                		"background-color":"#EC6B0E",
                	    });
                	 $(".btn2 li").eq(0).siblings("li").css({
                		"background-color":"black",
                	    "opacity":"0.4"
                	    }); 
              function slider3(){
              	     
               	     if(time1==3){
               	     	     $(".top2 ul li").eq(0).css({
               	     	     	'position':'relative',
               	     	     	'left':'4800px'
               	     	     });
               	     	time1=0;
               	     }else{
               	     	time1++;
               	     }
               	     time2++;
               	     $(".btn2 li").eq(time2).css({
                		"background-color":"#EC6B0E",
                	    "opacity":"1"
                	    });
                	 $(".btn2 li").eq(time2).siblings("li").css({
                		"background-color":"black",
                	    "opacity":"0.4"
                	    });
               	      $(".top2 ul").animate({"left":-1200*time2},1000,function(){
               	         if(time1==0){
               	         	$(".btn2 li").eq(time1).css({
                		       "background-color":"#EC6B0E",
                	            "opacity":"1"
                	     });
                	            $(".btn2 li").eq(time1).siblings("li").css({
                		        "background-color":"black",
                	              "opacity":"0.4"
                	    });
               	         	$(".top2 ul li").eq(0).css("position","static");
               	         	$(".top2 ul").css('left',0);
               	         	time2=0;
               	         }
               	      });
               	 }

                timeId3 = setInterval(slider3,3000);
  
                $('.btn2 li').mouseover(function(){
                	clearInterval(timeId3);
                });
                $('.btn2 li').mouseout(function(){
                	
                	timeId3 = setInterval(slider3,3000);
                });
                 $('.btn_left').mouseout(function(){
                	
                	timeId3 = setInterval(slider3,3000);
                }); 
                $('.btn_right').mouseout(function(){
                	
                	timeId3 = setInterval(slider3,3000);
                });
                $(".btn_left").click(function(){
                      clearInterval(timeId3);
                      if(time1==0){
                      	time1=3;
                      	time2=3;
                      }else{
                      	time1--;
               	        time2--;
                      }                	      
                      $(".btn2 li").eq(time2).css({
                		"background-color":"#EC6B0E",
                	    "opacity":"1"
                	    });
                	 $(".btn2 li").eq(time2).siblings("li").css({
                		"background-color":"black",
                	    "opacity":"0.4"
                	    });
               	      $(".top2 ul").animate({"left":-1200*time2},1000);
               	     
                });
                 $(".btn_right").click(function(){
                      clearInterval(timeId3);
                      if(time1==3){
                      	time1=0;
                      	time2=0;
                      }else{
                      	time1++;
               	        time2++;
                      }              	      
                      $(".btn2 li").eq(time2).css({
                		"background-color":"#EC6B0E",
                	    "opacity":"1"
                	    });
                	 $(".btn2 li").eq(time2).siblings("li").css({
                		"background-color":"black",
                	    "opacity":"0.4"
                	    });
               	      $(".top2 ul").animate({"left":-1200*time2},1000);
               	     
                });
                 $(".btn2 li").click(function(){
               	   var index3=$(this).index();
               	   time1=index3;  
               	   time2=index3;
               	   $(this).css({
                		"background-color":"#EC6B0E",
                	    "opacity":"1"
                	    });
                	 $(this).siblings("li").css({
                		"background-color":"black",
                	    "opacity":"0.4"
                	    });
               	   $(".top2 ul").animate({"left":-1200*index3},1000);
               }); 
                
                //满江红
               $(".center a").mouseover(function(){
               	$(this).css("color","red");
               });
                $(".center a").mouseout(function(){
               	$(this).css("color","black");
               });
                              
               $(".box2").click(function(){
               	$(this).css("background-color","#EC6B0E");
               	$(".box4").fadeIn("500");
               	$(".box3").css("background-color","#FFA900");
               	$(".box5").fadeOut("500");
               });
               
                $(".box3").click(function(){
               	$(this).css("background-color","#EC6B0E");
               	$(".box4").fadeOut("500");
               	$(".box2").css("background-color","#FFA900");
               	$(".box5").fadeIn("500");

               });
               
               $(".tab3 div").click(function(){
               	$(this).next("ul").slideDown().siblings("ul").slideUp();
               	$(this).css("background-color","#EC6B0E");
               	$(this).siblings("div").css("background-color","#FFA900");
               });
               
               $(".box6 div").click(function(){
               	  $(this).next("div").show();
               	  $(".mask").show();
               	  $(".close").show();
               });
               
               $(".close").click(function(){
               	 $(".copy7").hide();
               	 $(".mask").hide();
               	 $(".close").hide();
               });
               
               // tab2 图片轮播
               var now1=0;
               var now2=0;
               var timeId;   
               
               $(".box12 ul li").click(function(){
               	   var index2=$(this).index();
               	   now1=index2;  
               	   now2=index2;
               	   $(".box13").animate({"left":80*index2},0);
               	   $(".box11 ul").animate({"left":-315*index2},800);
               }); 
              function slider(){
               	     if(now1==3){
               	     	     $(".box11 ul li").eq(0).css({
               	     	     	'position':'relative',
               	     	     	'left':'1260px'
               	     	     });
               	     	now1=0;
               	     }else{
               	     	now1++;
               	     }
               	     now2++;
               	     $(".box13").animate({"left":80*now1},0);
               	      $(".box11 ul").animate({"left":-315*now2},800,function(){
               	         if(now1==0){
               	         	$(".box11 ul li").eq(0).css("position","static");
               	         	$(".box11 ul").css('left',0);
               	         	now2=0;
               	         }
               	      });
               	 }
               
                timeId = setInterval(slider,2400);
  
                $('.box12 ul li').mouseover(function(){
                	clearInterval(timeId);
                });
                $('.box12 ul li').mouseout(function(){
                	
                	timeId = setInterval(slider,2400);
                });
              
              
              //center底部图片轮播
                var t1=0;
                var t2=0;
                function slider2(){
               	     if(t1==1){
               	     	     $(".box14 ul li").eq(0).css({
               	     	     	'position':'relative',
               	     	     	'left':'924px'
               	     	     });             	     	                   	     	
               	     }else if(t1==2){
               	     	    $(".box14 ul li").eq(1).css({
               	     	     	'position':'relative',
               	     	     	'left':'924px'
               	     	    });             	      
               	      }else if(t1==3){
               	     	 
               	     	      $(".box14 ul li").eq(2).css({
               	     	     	'position':'relative',
               	     	     	'left':'924px'
               	     	     });
               	      
               	      }else if(t1==4){
               	     	 
               	     	      $(".box14 ul li").eq(3).css({
               	     	     	'position':'relative',
               	     	     	'left':'924px'
               	     	     });
               	      
               	      }else if(t1==6){
               	     	t1=0;
               	     }
               	     	
               	    t1++;
               	    t2++;
               	    $(".box14 ul").animate({"left":-154*t2},300,function(){
               	    	if(t2==6){
               	    		$(".box14>ul").css("left",0);
               	    		$(".box14>ul>li").eq(0).css({
               	     	     	'position':'static'
               	     	    });
               	     	    $(".box14>ul>li").eq(2).css({
               	     	     	'position':'static'
               	     	    });
               	     	    $(".box14>ul>li").eq(1).css({
               	     	     	'position':'static'
               	     	    });
               	     	    $(".box14>ul>li").eq(3).css({
               	     	     	'position':'static'
               	     	    });

               	     	    t2=0;
               	    	}
               	    });
               	 }
                timeId2 = setInterval(slider2,1800);
                
                $('.img9').mouseover(function(){
                	clearInterval(timeId2);
                });
                $('.img9').mouseout(function(){
                	
                	timeId2 = setInterval(slider2,1800);
                });
                 $('.img10').mouseover(function(){
                	clearInterval(timeId2);
                });
                $('.img10').mouseout(function(){
                	
                	timeId2 = setInterval(slider2,1800);
                });
                $(".img9").click(function(){
                	 $(".box14 ul").animate({"left":-154*(t2-1)},300);
                	 t1--;
                	 t2--;
                });
               $(".img10").click(function(){
                	 $(".box14 ul").animate({"left":-154*(t2+1)},300);
                	 t1++;
                	 t2++;
                }); 
                
                $(".bottom a").hover(function(){
                	$(this).css("color","red");
                });
                 $(".bottom a").mouseout(function(){
                	$(this).css("color","black");
                });               
	    });