<!DOCTYPE html>
<html>
	<head>
		<title>登录成功</title>
        <meta name="content-type"; charset="UTF-8">
        <script>
            alert("登录成功！点击确定后页面将自动跳转至Henu党委统战部主页！");
        </script>
	</head>
	<body>
	</body>
</html>
<?php
    header('refresh:1; url=1/index.php');
?>