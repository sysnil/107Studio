<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册成功!</title>
</head>
<script>
    alert('注册成功！确定后即将返回登录页面！');
</script>
</html>
<?php
    header('refresh:1; url=login.php');
?>