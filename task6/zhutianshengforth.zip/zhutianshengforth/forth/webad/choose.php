<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>注册选择页面</title>
		<style type="text/css">
			
		</style>
	</head>
	<body >
		<div class="box">
			<div class="btm1">
				<a href="register.php">注册为普通管理员</a>
			</div>
			<div class="btm2">
				<a href="adregister.php">注册为超级管理员</a>
			</div>
			
		</div>
		
	</body>
</html>
